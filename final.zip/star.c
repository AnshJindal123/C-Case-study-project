#include<stdio.h>
int star(int st)
{
    int i;
    for(i=0;i<st;i++)
    {
        printf("*");
    }
    return 0;
}
