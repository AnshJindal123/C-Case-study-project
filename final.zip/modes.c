#include<stdio.h>
int space(int s);
int star(int st);
void modes()
{
    space(10);printf("--MENU--\n");   
    space(10);printf("1. add extra student marks\n"); 
    space(10);printf("2. Grade detail\n");
    space(10);printf("3. Revaluation\n");
    space(10);printf("4. Logout\n");
    
}

