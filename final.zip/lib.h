int cases(int x,int *y);
void modes();
void front();
