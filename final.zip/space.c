#include<stdio.h>
int space(int s)
{
    int i;
    for(i=0;i<s;i++)
    {
        printf(" ");
    }
    return 0;
}
