#include<stdio.h>
int space(int s);
int star(int st);
void front()
{
    printf("\n");
    space(15);printf("People Eduducation Society\n\n");
    space(20);printf("Report Card\n");
    star(50);
    printf("\n");


}